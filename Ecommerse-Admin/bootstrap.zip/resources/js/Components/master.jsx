import React, { Component, Fragment } from 'react'

export default class App extends Component {
  render() {
    return (
      <Fragment>
            <h1 className='text-primary'>Robin Khan</h1>
      </Fragment>
    )
  }
}
